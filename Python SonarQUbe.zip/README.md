Run this command to install the libraries needed.

pip3 install -r requirements.txt 